
-- =========================================================
-- LABORATORIO #3: SISTEMA DE INVENTARIO ADUANERO
-- Gestor: MySQL 8.0
-- Integrante(s): Audry Quiros Chavarria
-- Fecha: 23/10/26
-- =========================================================

CREATE DATABASE IF NOT EXISTS aduana
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE aduana;

-- 1. IMPORTADORES
CREATE TABLE IF NOT EXISTS importadores (
    id_importador INT AUTO_INCREMENT PRIMARY KEY,
    razon_social VARCHAR(120) NOT NULL,
    identificacion VARCHAR(30) NOT NULL UNIQUE,
    direccion VARCHAR(200),
    telefono VARCHAR(25),
    correo VARCHAR(120),
    CONSTRAINT uq_importador_correo UNIQUE (correo)
);

-- 2. AGENTES ADUANALES
CREATE TABLE IF NOT EXISTS agentes_aduanales (
    id_agente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    licencia VARCHAR(40) NOT NULL UNIQUE,
    telefono VARCHAR(25)
);

-- 3. PAISES
CREATE TABLE IF NOT EXISTS paises (
    id_pais INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL UNIQUE,
    codigo_iso CHAR(2) NOT NULL UNIQUE
);

-- 4. CATEGORIAS ARANCELARIAS
CREATE TABLE IF NOT EXISTS categorias_arancelarias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    descripcion VARCHAR(200) NOT NULL,
    porcentaje_arancel DECIMAL(5,2) NOT NULL DEFAULT 0,
    CONSTRAINT chk_categoria_arancel
        CHECK (porcentaje_arancel BETWEEN 0 AND 100)
);

-- 5. PRODUCTOS
CREATE TABLE IF NOT EXISTS productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(150) NOT NULL,
    unidad_medida VARCHAR(30) NOT NULL,
    valor_unitario DECIMAL(12,2) NOT NULL,
    id_categoria INT NOT NULL,
    CONSTRAINT chk_producto_valor
        CHECK (valor_unitario >= 0),
    CONSTRAINT fk_producto_categoria
        FOREIGN KEY (id_categoria)
        REFERENCES categorias_arancelarias(id_categoria)
);

-- 6. DECLARACIONES
CREATE TABLE IF NOT EXISTS declaraciones (
    id_declaracion INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(30) NOT NULL UNIQUE,
    fecha DATE NOT NULL,
    regimen VARCHAR(20) NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'Retenida',
    id_importador INT NOT NULL,
    id_agente INT NOT NULL,
    id_pais_origen INT NOT NULL,

    CONSTRAINT chk_declaracion_regimen
        CHECK (regimen IN
            ('Importacion', 'Exportacion', 'Transito', 'Deposito')),

    CONSTRAINT chk_declaracion_estado
        CHECK (estado IN
            ('Retenida', 'En revision', 'Liberada', 'Rechazada')),

    CONSTRAINT fk_declaracion_importador
        FOREIGN KEY (id_importador)
        REFERENCES importadores(id_importador),

    CONSTRAINT fk_declaracion_agente
        FOREIGN KEY (id_agente)
        REFERENCES agentes_aduanales(id_agente),

    CONSTRAINT fk_declaracion_pais
        FOREIGN KEY (id_pais_origen)
        REFERENCES paises(id_pais)
);

-- 7. DETALLE DE DECLARACION
-- Resuelve la relacion N:M entre declaraciones y productos.
CREATE TABLE IF NOT EXISTS detalle_declaracion (
    id_declaracion INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad DECIMAL(12,2) NOT NULL,
    valor_declarado DECIMAL(14,2) NOT NULL,

    PRIMARY KEY (id_declaracion, id_producto),

    CONSTRAINT chk_detalle_cantidad
        CHECK (cantidad > 0),

    CONSTRAINT chk_detalle_valor
        CHECK (valor_declarado >= 0),

    CONSTRAINT fk_detalle_declaracion
        FOREIGN KEY (id_declaracion)
        REFERENCES declaraciones(id_declaracion),

    CONSTRAINT fk_detalle_producto
        FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto)
);

-- 8. CONTENEDORES
CREATE TABLE IF NOT EXISTS contenedores (
    id_contenedor INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(30) NOT NULL UNIQUE,
    tipo VARCHAR(30) NOT NULL,
    peso DECIMAL(12,2) NOT NULL,
    id_declaracion INT NOT NULL,

    CONSTRAINT chk_contenedor_peso
        CHECK (peso > 0),

    CONSTRAINT fk_contenedor_declaracion
        FOREIGN KEY (id_declaracion)
        REFERENCES declaraciones(id_declaracion)
);

-- 9. BODEGAS
CREATE TABLE IF NOT EXISTS bodegas (
    id_bodega INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    ubicacion VARCHAR(200) NOT NULL,
    capacidad DECIMAL(12,2) NOT NULL,

    CONSTRAINT chk_bodega_capacidad
        CHECK (capacidad > 0)
);

-- 10. INVENTARIO
CREATE TABLE IF NOT EXISTS inventario (
    id_inventario INT AUTO_INCREMENT PRIMARY KEY,
    id_bodega INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad DECIMAL(12,2) NOT NULL DEFAULT 0,
    fecha_ingreso DATE NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'Retenido',

    CONSTRAINT uq_inventario_bodega_producto
        UNIQUE (id_bodega, id_producto),

    CONSTRAINT chk_inventario_cantidad
        CHECK (cantidad >= 0),

    CONSTRAINT chk_inventario_estado
        CHECK (estado IN ('Retenido', 'Liberado')),

    CONSTRAINT fk_inventario_bodega
        FOREIGN KEY (id_bodega)
        REFERENCES bodegas(id_bodega),

    CONSTRAINT fk_inventario_producto
        FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto)
);

-- 11. MOVIMIENTOS DE INVENTARIO
CREATE TABLE IF NOT EXISTS movimientos_inventario (
    id_movimiento INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(20) NOT NULL,
    fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cantidad DECIMAL(12,2) NOT NULL,
    id_producto INT NOT NULL,
    id_bodega_origen INT,
    id_bodega_destino INT,

    CONSTRAINT chk_movimiento_tipo
        CHECK (tipo IN ('Entrada', 'Salida', 'Traslado')),

    CONSTRAINT chk_movimiento_cantidad
        CHECK (cantidad > 0),

    CONSTRAINT chk_movimiento_bodegas
        CHECK (
            (tipo = 'Entrada'
                AND id_bodega_destino IS NOT NULL
                AND id_bodega_origen IS NULL)
            OR
            (tipo = 'Salida'
                AND id_bodega_origen IS NOT NULL
                AND id_bodega_destino IS NULL)
            OR
            (tipo = 'Traslado'
                AND id_bodega_origen IS NOT NULL
                AND id_bodega_destino IS NOT NULL
                AND id_bodega_origen <> id_bodega_destino)
        ),

    CONSTRAINT fk_movimiento_producto
        FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto),

    CONSTRAINT fk_movimiento_origen
        FOREIGN KEY (id_bodega_origen)
        REFERENCES bodegas(id_bodega),

    CONSTRAINT fk_movimiento_destino
        FOREIGN KEY (id_bodega_destino)
        REFERENCES bodegas(id_bodega)
);

-- 12. FUNCIONARIOS
CREATE TABLE IF NOT EXISTS funcionarios (
    id_funcionario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    cargo VARCHAR(80) NOT NULL,
    id_supervisor INT NULL,

    CONSTRAINT fk_funcionario_supervisor
        FOREIGN KEY (id_supervisor)
        REFERENCES funcionarios(id_funcionario)
);

-- 13. INSPECCIONES
CREATE TABLE IF NOT EXISTS inspecciones (
    id_inspeccion INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    resultado VARCHAR(30) NOT NULL,
    observaciones TEXT,
    id_declaracion INT NOT NULL,
    id_funcionario INT NOT NULL,

    CONSTRAINT chk_inspeccion_resultado
        CHECK (resultado IN
            ('Aprobada', 'Rechazada', 'Con observaciones')),

    CONSTRAINT fk_inspeccion_declaracion
        FOREIGN KEY (id_declaracion)
        REFERENCES declaraciones(id_declaracion),

    CONSTRAINT fk_inspeccion_funcionario
        FOREIGN KEY (id_funcionario)
        REFERENCES funcionarios(id_funcionario)
);

-- Agregar nombre a la tabla productos para mejor manejo de la misma
ALTER TABLE productos
ADD COLUMN nombre VARCHAR(120) NOT NULL DEFAULT 'Sin nombre'
AFTER id_producto;

-- FIN DE LA ESTRUCTURA
-- Los INSERT y las consultas se agregaran despues.
