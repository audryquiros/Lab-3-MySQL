-- =========================================================
-- LABORATORIO #3: SISTEMA DE INVENTARIO ADUANERO
-- CONSULTAS SQL DE PRUEBA
-- Gestor: MySQL 8.0
-- Base de datos: aduana
-- Propósito: demostrar consultas con JOIN, WHERE, GROUP BY y ORDER BY.
-- =========================================================

USE aduana;

-- =========================================================
-- CONSULTA 1. DECLARACIONES CON SUS IMPORTADORES
-- JOIN: relaciona declaraciones con importadores.
-- ORDER BY: muestra primero las declaraciones más recientes.
-- =========================================================
SELECT
    d.numero AS numero_declaracion,
    d.fecha,
    d.regimen,
    d.estado,
    i.razon_social AS importador
FROM declaraciones AS d
INNER JOIN importadores AS i
    ON d.id_importador = i.id_importador
ORDER BY d.fecha DESC;

-- =========================================================
-- CONSULTA 2. DECLARACIONES CON PAIS DE ORIGEN Y AGENTE
-- JOIN: combina tres tablas relacionadas.
-- WHERE: filtra declaraciones que aún no están liberadas.
-- =========================================================
SELECT
    d.numero AS numero_declaracion,
    p.nombre AS pais_origen,
    a.nombre AS agente_aduanal,
    d.estado
FROM declaraciones AS d
INNER JOIN paises AS p
    ON d.id_pais_origen = p.id_pais
INNER JOIN agentes_aduanales AS a
    ON d.id_agente = a.id_agente
WHERE d.estado <> 'Liberada'
ORDER BY d.fecha DESC;

-- =========================================================
-- CONSULTA 3. PRODUCTOS CON SU CATEGORIA ARANCELARIA
-- JOIN: obtiene la descripción de la categoría asociada.
-- ORDER BY: ordena por porcentaje de arancel de mayor a menor.
-- =========================================================
SELECT
    pr.id_producto,
    pr.nombre AS producto,
    pr.descripcion,
    pr.unidad_medida,
    pr.valor_unitario,
    ca.codigo AS codigo_categoria,
    ca.descripcion AS categoria,
    ca.porcentaje_arancel
FROM productos AS pr
INNER JOIN categorias_arancelarias AS ca
    ON pr.id_categoria = ca.id_categoria
ORDER BY ca.porcentaje_arancel DESC, pr.nombre ASC;

-- =========================================================
-- CONSULTA 4. EXISTENCIAS POR BODEGA Y PRODUCTO
-- JOIN: muestra el nombre de la bodega y del producto.
-- WHERE: muestra únicamente artículos con cantidad mayor que cero.
-- =========================================================
SELECT
    b.nombre AS bodega,
    pr.nombre AS producto,
    inv.cantidad,
    pr.unidad_medida,
    inv.estado,
    inv.fecha_ingreso
FROM inventario AS inv
INNER JOIN bodegas AS b
    ON inv.id_bodega = b.id_bodega
INNER JOIN productos AS pr
    ON inv.id_producto = pr.id_producto
WHERE inv.cantidad > 0
ORDER BY b.nombre ASC, pr.nombre ASC;

-- =========================================================
-- CONSULTA 5. HISTORIAL DE MOVIMIENTOS DE INVENTARIO
-- JOIN: muestra el producto y las bodegas involucradas.
-- CASE: presenta un nombre legible cuando origen o destino es NULL.
-- =========================================================
SELECT
    mi.id_movimiento,
    mi.fecha,
    mi.tipo,
    pr.nombre AS producto,
    mi.cantidad,
    COALESCE(bo.nombre, 'Sin bodega de origen') AS bodega_origen,
    COALESCE(bd.nombre, 'Sin bodega de destino') AS bodega_destino
FROM movimientos_inventario AS mi
INNER JOIN productos AS pr
    ON mi.id_producto = pr.id_producto
LEFT JOIN bodegas AS bo
    ON mi.id_bodega_origen = bo.id_bodega
LEFT JOIN bodegas AS bd
    ON mi.id_bodega_destino = bd.id_bodega
ORDER BY mi.fecha DESC;

-- =========================================================
-- CONSULTA 6. CANTIDAD DE DECLARACIONES POR ESTADO
-- GROUP BY: agrupa las declaraciones según su estado.
-- ORDER BY: ordena por cantidad de mayor a menor.
-- =========================================================
SELECT
    estado,
    COUNT(*) AS total_declaraciones
FROM declaraciones
GROUP BY estado
ORDER BY total_declaraciones DESC, estado ASC;

-- =========================================================
-- CONSULTA 7. VALOR TOTAL DECLARADO POR DECLARACION
-- JOIN + GROUP BY: suma el valor declarado registrado en cada línea.
-- En estos datos de prueba, valor_declarado representa el total de la línea.
-- =========================================================
SELECT
    d.numero AS numero_declaracion,
    d.fecha,
    i.razon_social AS importador,
    SUM(dd.valor_declarado) AS valor_total_declarado
FROM declaraciones AS d
INNER JOIN importadores AS i
    ON d.id_importador = i.id_importador
INNER JOIN detalle_declaracion AS dd
    ON d.id_declaracion = dd.id_declaracion
GROUP BY
    d.id_declaracion,
    d.numero,
    d.fecha,
    i.razon_social
ORDER BY valor_total_declarado DESC;

-- =========================================================
-- CONSULTA 8. INSPECCIONES CON FUNCIONARIOS Y DECLARACIONES
-- JOIN: identifica quién inspeccionó cada declaración.
-- WHERE: muestra inspecciones aprobadas o con observaciones.
-- =========================================================
SELECT
    ins.fecha,
    ins.resultado,
    ins.observaciones,
    d.numero AS numero_declaracion,
    f.nombre AS funcionario,
    f.cargo
FROM inspecciones AS ins
INNER JOIN declaraciones AS d
    ON ins.id_declaracion = d.id_declaracion
INNER JOIN funcionarios AS f
    ON ins.id_funcionario = f.id_funcionario
WHERE ins.resultado IN ('Aprobada', 'Con observaciones')
ORDER BY ins.fecha DESC;

-- =========================================================
-- FIN DE LAS 8 CONSULTAS SQL
-- =========================================================
