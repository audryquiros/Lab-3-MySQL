
-- =========================================================
-- LABORATORIO #3: SISTEMA DE INVENTARIO ADUANERO
-- USUARIO DE SOLO LECTURA PARA EL AGENTE DE IA
-- =========================================================

-- Crear un usuario exclusivo para las consultas del agente.
CREATE USER IF NOT EXISTS 'aduana_lector'@'localhost'
IDENTIFIED BY 'AduanaLectura_2026!';

-- Permitir únicamente consultas en la base de datos aduana.
GRANT SELECT ON aduana.* TO 'aduana_lector'@'localhost';

-- Comprobar los permisos asignados.
SHOW GRANTS FOR 'aduana_lector'@'localhost';
