-- =========================================================
-- LABORATORIO #3: SISTEMA DE INVENTARIO ADUANERO
-- SCRIPT DE DATOS DE PRUEBA
-- Gestor: MySQL 8.0
-- Base de datos: aduana
-- Propósito: insertar 15 registros en cada una de las 13 tablas.
-- Total esperado: 195 registros.
-- IMPORTANTE:
--   1. Ejecutar después de crear todas las tablas.
--   2. La base debe estar vacía para evitar conflictos de IDs.
--   3. La tabla productos debe tener la columna nombre.
--   4. No ejecutar repetidamente sobre los mismos datos.
-- =========================================================

USE aduana;

-- =========================================================
-- ORDEN DE INSERCIÓN
-- Las tablas principales se llenan primero para que existan
-- las referencias requeridas por las claves foráneas.
-- =========================================================

START TRANSACTION;

-- Los INSERT se ejecutan dentro de una transacción.

-- 1. IMPORTADORES
-- Datos de empresas que realizan operaciones aduaneras.
INSERT INTO importadores (razon_social, identificacion, direccion, telefono, correo) VALUES
('Comercial La Ceiba S.A.', '3-101-100001', 'San José, Costa Rica', '2222-1001', 'contacto@laceiba.example'),
('Importadora del Valle S.A.', '3-101-100002', 'Heredia, Costa Rica', '2222-1002', 'contacto@delvalle.example'),
('Distribuidora Horizonte S.A.', '3-101-100003', 'Alajuela, Costa Rica', '2222-1003', 'contacto@horizonte.example'),
('Tecnología Global CR S.A.', '3-101-100004', 'Cartago, Costa Rica', '2222-1004', 'contacto@tecnologiaglobal.example'),
('Alimentos del Pacífico S.A.', '3-101-100005', 'Puntarenas, Costa Rica', '2222-1005', 'contacto@pacifico.example'),
('Textiles del Este S.A.', '3-101-100006', 'Limón, Costa Rica', '2222-1006', 'contacto@textileseste.example'),
('Hogar Moderno S.A.', '3-101-100007', 'San José, Costa Rica', '2222-1007', 'contacto@hogarmoderno.example'),
('Ferretería Central S.A.', '3-101-100008', 'Heredia, Costa Rica', '2222-1008', 'contacto@ferreteriacentral.example'),
('Farmacéutica del Sur S.A.', '3-101-100009', 'Pérez Zeledón, Costa Rica', '2222-1009', 'contacto@farmasur.example'),
('Autopartes Ticas S.A.', '3-101-100010', 'Alajuela, Costa Rica', '2222-1010', 'contacto@autopartes.example'),
('Muebles Roble S.A.', '3-101-100011', 'San José, Costa Rica', '2222-1011', 'contacto@mueblesroble.example'),
('Papelería Escolar S.A.', '3-101-100012', 'Cartago, Costa Rica', '2222-1012', 'contacto@papeleriaescolar.example'),
('Agroinsumos Verdes S.A.', '3-101-100013', 'Guanacaste, Costa Rica', '2222-1013', 'contacto@agroverdes.example'),
('Electrodomésticos del Norte S.A.', '3-101-100014', 'San Carlos, Costa Rica', '2222-1014', 'contacto@electronorte.example'),
('Juguetes Arcoíris S.A.', '3-101-100015', 'Desamparados, Costa Rica', '2222-1015', 'contacto@arcoiris.example');

-- 2. AGENTES ADUANALES
-- Agentes responsables de tramitar declaraciones.
INSERT INTO agentes_aduanales (nombre, licencia, telefono) VALUES
('María Fernanda Solís', 'AA-CR-1001', '8888-1001'),
('Carlos Andrés Mora', 'AA-CR-1002', '8888-1002'),
('Daniela Rojas Vargas', 'AA-CR-1003', '8888-1003'),
('José Pablo Méndez', 'AA-CR-1004', '8888-1004'),
('Andrea Jiménez León', 'AA-CR-1005', '8888-1005'),
('Luis Fernando Castro', 'AA-CR-1006', '8888-1006'),
('Valeria Chacón Ruiz', 'AA-CR-1007', '8888-1007'),
('Esteban Ramírez Soto', 'AA-CR-1008', '8888-1008'),
('Natalia Vargas Campos', 'AA-CR-1009', '8888-1009'),
('Ricardo Quesada Arias', 'AA-CR-1010', '8888-1010'),
('Paola Herrera Núñez', 'AA-CR-1011', '8888-1011'),
('Marco Antonio León', 'AA-CR-1012', '8888-1012'),
('Sofía Calderón Vega', 'AA-CR-1013', '8888-1013'),
('Gabriel Navarro Díaz', 'AA-CR-1014', '8888-1014'),
('Isabel Pineda Solano', 'AA-CR-1015', '8888-1015');

-- 3. PAISES
-- Países de origen de las mercancías; cada código ISO es único.
INSERT INTO paises (nombre, codigo_iso) VALUES
('Estados Unidos', 'US'), ('China', 'CN'), ('México', 'MX'), ('Panamá', 'PA'),
('Colombia', 'CO'), ('Japón', 'JP'), ('Alemania', 'DE'), ('España', 'ES'),
('Brasil', 'BR'), ('Chile', 'CL'), ('Canadá', 'CA'), ('Italia', 'IT'),
('Corea del Sur', 'KR'), ('India', 'IN'), ('Países Bajos', 'NL');

-- 4. CATEGORIAS ARANCELARIAS
-- Porcentajes dentro del rango permitido por chk_categoria_arancel.
INSERT INTO categorias_arancelarias (codigo, descripcion, porcentaje_arancel) VALUES
('CAT-001', 'Electrónica y tecnología', 5.00),
('CAT-002', 'Textiles y prendas de vestir', 10.00),
('CAT-003', 'Alimentos procesados', 8.00),
('CAT-004', 'Herramientas y ferretería', 7.50),
('CAT-005', 'Productos farmacéuticos', 2.00),
('CAT-006', 'Muebles y artículos de madera', 12.00),
('CAT-007', 'Papelería y material escolar', 6.00),
('CAT-008', 'Repuestos automotrices', 9.00),
('CAT-009', 'Juguetes y recreación', 10.00),
('CAT-010', 'Maquinaria industrial', 4.50),
('CAT-011', 'Productos agrícolas', 3.00),
('CAT-012', 'Artículos para el hogar', 11.00),
('CAT-013', 'Calzado y accesorios', 9.50),
('CAT-014', 'Plásticos y empaques', 6.50),
('CAT-015', 'Equipos de seguridad', 5.50);

-- 5. PRODUCTOS
-- Incluye nombre, descripción, unidad, valor y categoría arancelaria.
INSERT INTO productos (nombre, descripcion, unidad_medida, valor_unitario, id_categoria) VALUES
('Laptop empresarial', 'Computadora portátil para oficina', 'unidad', 650.00, 1),
('Camiseta de algodón', 'Camiseta básica de algodón', 'unidad', 6.50, 2),
('Café tostado', 'Café tostado empacado', 'kilogramo', 8.25, 3),
('Taladro eléctrico', 'Taladro eléctrico de uso general', 'unidad', 45.00, 4),
('Guantes médicos', 'Guantes desechables para uso médico', 'caja', 12.00, 5),
('Mesa de madera', 'Mesa de madera para interiores', 'unidad', 120.00, 6),
('Cuaderno universitario', 'Cuaderno de 100 hojas', 'unidad', 1.80, 7),
('Filtro de aceite', 'Filtro para motor de vehículo', 'unidad', 7.50, 8),
('Juego de bloques', 'Juguete de bloques de construcción', 'unidad', 18.00, 9),
('Bomba industrial', 'Bomba para uso industrial', 'unidad', 480.00, 10),
('Semillas de maíz', 'Semillas seleccionadas para siembra', 'kilogramo', 3.25, 11),
('Licuadora doméstica', 'Licuadora eléctrica para cocina', 'unidad', 32.00, 12),
('Zapatos de seguridad', 'Calzado de seguridad industrial', 'par', 38.00, 13),
('Envases plásticos', 'Envases plásticos para empaque', 'paquete', 14.00, 14),
('Casco protector', 'Casco para protección industrial', 'unidad', 16.00, 15);

-- 6. DECLARACIONES
-- Cada declaración referencia un importador, un agente y un país existentes.
INSERT INTO declaraciones (numero, fecha, regimen, estado, id_importador, id_agente, id_pais_origen) VALUES
('D-2026-0001', '2026-01-08', 'Importacion', 'Retenida', 1, 1, 1),
('D-2026-0002', '2026-01-12', 'Importacion', 'Liberada', 2, 2, 2),
('D-2026-0003', '2026-01-17', 'Transito', 'En revision', 3, 3, 3),
('D-2026-0004', '2026-01-22', 'Importacion', 'Liberada', 4, 4, 4),
('D-2026-0005', '2026-02-02', 'Deposito', 'Retenida', 5, 5, 5),
('D-2026-0006', '2026-02-09', 'Exportacion', 'Liberada', 6, 6, 6),
('D-2026-0007', '2026-02-14', 'Importacion', 'Rechazada', 7, 7, 7),
('D-2026-0008', '2026-02-20', 'Transito', 'Liberada', 8, 8, 8),
('D-2026-0009', '2026-03-01', 'Importacion', 'En revision', 9, 9, 9),
('D-2026-0010', '2026-03-05', 'Importacion', 'Liberada', 10, 10, 10),
('D-2026-0011', '2026-03-11', 'Deposito', 'Retenida', 11, 11, 11),
('D-2026-0012', '2026-03-18', 'Exportacion', 'Liberada', 12, 12, 12),
('D-2026-0013', '2026-04-03', 'Importacion', 'En revision', 13, 13, 13),
('D-2026-0014', '2026-04-11', 'Transito', 'Liberada', 14, 14, 14),
('D-2026-0015', '2026-04-19', 'Importacion', 'Retenida', 15, 15, 15);

-- 7. DETALLE DE DECLARACION
-- Relaciona declaraciones y productos (N:M); no se repite la pareja de IDs.
INSERT INTO detalle_declaracion (id_declaracion, id_producto, cantidad, valor_declarado) VALUES
(1, 1, 10, 6500.00), (2, 2, 500, 3250.00), (3, 3, 120, 990.00),
(4, 4, 40, 1800.00), (5, 5, 200, 2400.00), (6, 6, 25, 3000.00),
(7, 7, 1000, 1800.00), (8, 8, 300, 2250.00), (9, 9, 150, 2700.00),
(10, 10, 8, 3840.00), (11, 11, 600, 1950.00), (12, 12, 70, 2240.00),
(13, 13, 90, 3420.00), (14, 14, 250, 3500.00), (15, 15, 180, 2880.00);

-- 8. CONTENEDORES
-- Cada contenedor se asocia a una declaración existente y tiene peso positivo.
INSERT INTO contenedores (numero, tipo, peso, id_declaracion) VALUES
('CONT-0001', '20 pies', 8500.00, 1), ('CONT-0002', '40 pies', 12000.00, 2),
('CONT-0003', '20 pies', 7200.00, 3), ('CONT-0004', '40 pies', 14500.00, 4),
('CONT-0005', 'Refrigerado', 9000.00, 5), ('CONT-0006', '20 pies', 6800.00, 6),
('CONT-0007', '40 pies', 15800.00, 7), ('CONT-0008', '20 pies', 8100.00, 8),
('CONT-0009', 'Refrigerado', 10200.00, 9), ('CONT-0010', '40 pies', 13200.00, 10),
('CONT-0011', '20 pies', 7600.00, 11), ('CONT-0012', '40 pies', 14000.00, 12),
('CONT-0013', '20 pies', 8300.00, 13), ('CONT-0014', 'Refrigerado', 9700.00, 14),
('CONT-0015', '40 pies', 15100.00, 15);

-- 9. BODEGAS
-- Ubicaciones de almacenamiento con capacidad positiva.
INSERT INTO bodegas (nombre, ubicacion, capacidad) VALUES
('Bodega Central', 'Zona primaria, sector A', 50000.00),
('Bodega Norte', 'Zona primaria, sector B', 35000.00),
('Bodega Sur', 'Zona secundaria, sector A', 30000.00),
('Bodega Este', 'Zona secundaria, sector B', 28000.00),
('Bodega Oeste', 'Terminal de carga, sector A', 32000.00),
('Bodega Refrigerada 1', 'Terminal refrigerada, cámara 1', 18000.00),
('Bodega Refrigerada 2', 'Terminal refrigerada, cámara 2', 16000.00),
('Bodega Electrónica', 'Zona de mercancía sensible', 12000.00),
('Bodega Textil', 'Zona de textiles', 22000.00),
('Bodega Alimentos', 'Zona de alimentos', 20000.00),
('Bodega Química', 'Zona de productos controlados', 14000.00),
('Bodega Temporal 1', 'Patio temporal, módulo 1', 10000.00),
('Bodega Temporal 2', 'Patio temporal, módulo 2', 10000.00),
('Bodega Inspección', 'Área de revisión física', 8000.00),
('Bodega Liberados', 'Área de mercancía liberada', 25000.00);

-- 10. INVENTARIO
-- Cada combinación bodega-producto aparece una sola vez.
INSERT INTO inventario (id_bodega, id_producto, cantidad, fecha_ingreso, estado) VALUES
(1, 1, 10, '2026-01-08', 'Retenido'),
(2, 2, 500, '2026-01-12', 'Liberado'),
(3, 3, 120, '2026-01-17', 'Retenido'),
(4, 4, 40, '2026-01-22', 'Liberado'),
(5, 5, 200, '2026-02-02', 'Retenido'),
(6, 6, 25, '2026-02-09', 'Liberado'),
(7, 7, 1000, '2026-02-14', 'Retenido'),
(8, 8, 300, '2026-02-20', 'Liberado'),
(9, 9, 150, '2026-03-01', 'Retenido'),
(10, 10, 8, '2026-03-05', 'Liberado'),
(11, 11, 600, '2026-03-11', 'Retenido'),
(12, 12, 70, '2026-03-18', 'Liberado'),
(13, 13, 90, '2026-04-03', 'Retenido'),
(14, 14, 250, '2026-04-11', 'Liberado'),
(15, 15, 180, '2026-04-19', 'Retenido');

-- 11. MOVIMIENTOS DE INVENTARIO
-- Se validan las bodegas según Entrada, Salida o Traslado.
INSERT INTO movimientos_inventario (tipo, fecha, cantidad, id_producto, id_bodega_origen, id_bodega_destino) VALUES
('Entrada', '2026-01-08 08:30:00', 10, 1, NULL, 1),
('Salida', '2026-01-09 09:15:00', 2, 1, 1, NULL),
('Traslado', '2026-01-12 10:00:00', 20, 2, 2, 3),
('Entrada', '2026-01-17 11:30:00', 120, 3, NULL, 4),
('Salida', '2026-01-22 12:45:00', 5, 4, 4, NULL),
('Traslado', '2026-02-02 13:00:00', 10, 5, 5, 6),
('Entrada', '2026-02-09 08:10:00', 25, 6, NULL, 7),
('Salida', '2026-02-14 14:20:00', 50, 7, 7, NULL),
('Traslado', '2026-02-20 15:00:00', 15, 8, 8, 9),
('Entrada', '2026-03-01 07:55:00', 150, 9, NULL, 10),
('Salida', '2026-03-05 16:10:00', 1, 10, 10, NULL),
('Traslado', '2026-03-11 17:00:00', 30, 11, 11, 12),
('Entrada', '2026-03-18 08:40:00', 70, 12, NULL, 13),
('Salida', '2026-04-03 09:50:00', 10, 13, 13, NULL),
('Traslado', '2026-04-11 10:25:00', 25, 14, 14, 15);

-- Primero se insertan sin supervisor para evitar depender del orden
-- de evaluación de claves foráneas autorreferenciadas.
-- 12. FUNCIONARIOS
-- Primero se crean los funcionarios; luego se asignan supervisores válidos.
INSERT INTO funcionarios (nombre, cargo, id_supervisor) VALUES
('Roberto Salazar', 'Jefe de aduana', NULL),
('Ana Lucía Brenes', 'Supervisora de inspección', NULL),
('Miguel Ángel Soto', 'Inspector aduanero', NULL),
('Karla Méndez', 'Inspectora aduanera', NULL),
('Diego Ramírez', 'Analista documental', NULL),
('Paola Jiménez', 'Oficial de inventario', NULL),
('Andrés Castro', 'Inspector de carga', NULL),
('Sofía Herrera', 'Auxiliar aduanera', NULL),
('José Vargas', 'Oficial de control', NULL),
('Mariana Rojas', 'Analista de riesgo', NULL),
('Felipe Navarro', 'Inspector de contenedores', NULL),
('Daniela León', 'Coordinadora logística', NULL),
('Esteban Chaves', 'Auxiliar de bodega', NULL),
('Valentina Mora', 'Inspectora de mercancías', NULL),
('Gabriel Quesada', 'Oficial de revisión', NULL);

-- Se asignan supervisores después de crear los 15 funcionarios.
UPDATE funcionarios SET id_supervisor = 1 WHERE id_funcionario IN (2, 5, 6, 12);
UPDATE funcionarios SET id_supervisor = 2 WHERE id_funcionario IN (3, 4, 7, 9, 11, 14);
UPDATE funcionarios SET id_supervisor = 5 WHERE id_funcionario IN (8, 10, 15);
UPDATE funcionarios SET id_supervisor = 6 WHERE id_funcionario = 13;

-- 13. INSPECCIONES
-- Cada inspección referencia una declaración y un funcionario existentes.
INSERT INTO inspecciones (fecha, resultado, observaciones, id_declaracion, id_funcionario) VALUES
('2026-01-09', 'Con observaciones', 'Se solicita revisar documentación complementaria.', 1, 2),
('2026-01-13', 'Aprobada', 'Documentación y mercancía conformes.', 2, 3),
('2026-01-18', 'Con observaciones', 'Pendiente confirmar clasificación arancelaria.', 3, 4),
('2026-01-23', 'Aprobada', 'Peso verificado sin diferencias.', 4, 7),
('2026-02-03', 'Con observaciones', 'Mercancía en espera de inspección física.', 5, 11),
('2026-02-10', 'Aprobada', 'Revisión documental satisfactoria.', 6, 9),
('2026-02-15', 'Rechazada', 'Diferencias entre documentos y mercancía.', 7, 14),
('2026-02-21', 'Aprobada', 'Contenedor revisado y sellos conformes.', 8, 3),
('2026-03-02', 'Con observaciones', 'Se requiere certificado adicional.', 9, 10),
('2026-03-06', 'Aprobada', 'Cantidad declarada verificada.', 10, 7),
('2026-03-12', 'Con observaciones', 'Se mantiene retención preventiva.', 11, 11),
('2026-03-19', 'Aprobada', 'Inspección final completada.', 12, 4),
('2026-04-04', 'Con observaciones', 'Se solicita aclaración del valor declarado.', 13, 14),
('2026-04-12', 'Aprobada', 'Mercancía autorizada para continuar trámite.', 14, 9),
('2026-04-20', 'Con observaciones', 'Pendiente resolución de revisión documental.', 15, 10);

COMMIT;

-- =========================================================
-- VERIFICACION FINAL
-- Debe mostrar 15 registros en cada una de las 13 tablas.
-- =========================================================
SELECT 'importadores' AS tabla, COUNT(*) AS registros FROM importadores
UNION ALL SELECT 'agentes_aduanales', COUNT(*) FROM agentes_aduanales
UNION ALL SELECT 'paises', COUNT(*) FROM paises
UNION ALL SELECT 'categorias_arancelarias', COUNT(*) FROM categorias_arancelarias
UNION ALL SELECT 'productos', COUNT(*) FROM productos
UNION ALL SELECT 'declaraciones', COUNT(*) FROM declaraciones
UNION ALL SELECT 'detalle_declaracion', COUNT(*) FROM detalle_declaracion
UNION ALL SELECT 'contenedores', COUNT(*) FROM contenedores
UNION ALL SELECT 'bodegas', COUNT(*) FROM bodegas
UNION ALL SELECT 'inventario', COUNT(*) FROM inventario
UNION ALL SELECT 'movimientos_inventario', COUNT(*) FROM movimientos_inventario
UNION ALL SELECT 'funcionarios', COUNT(*) FROM funcionarios
UNION ALL SELECT 'inspecciones', COUNT(*) FROM inspecciones;

-- FIN DEL SCRIPT DE DATOS DE PRUEBA
